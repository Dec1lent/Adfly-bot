#Loops
for i in range(50):
    try:
#Modules
        from selenium import webdriver
        from selenium.webdriver.chrome.options import Options
        from selenium.webdriver.common.proxy import Proxy, ProxyType
        import requests
        import random
        from fake_useragent import UserAgent
        from time import sleep
        from selenium.webdriver.support.ui import WebDriverWait
        from selenium.webdriver.support import expected_conditions as EC
        from selenium.webdriver.common.by import By
        from selenium.webdriver.chrome.options import Options
        from selenium.webdriver.common.keys import Keys
        from selenium.webdriver.common.desired_capabilities import DesiredCapabilities
        import os
        from colorama import Fore, Back, Style
        import threading
#Proxy  
        Ips = open('Ips.txt').read().splitlines()
        proxy_ip_port = random.choice(Ips)
        print(proxy_ip_port)
        proxy = Proxy()
        proxy.proxy_type = ProxyType.MANUAL
        proxy.http_proxy = proxy_ip_port
        proxy.ssl_proxy = proxy_ip_port

        capabilities = webdriver.DesiredCapabilities.CHROME
        proxy.add_to_capabilities(capabilities)
#Options    
        options = Options()
        options.add_extension('Extensions/fingerprint_defender.zip')
        options.add_extension('Extensions/spoof_timezone.zip')
        options.add_extension('Extensions/ampbrowser.crx')
        #Windows-Size-Random
        Resolutions = ['1920,1080','1600,900','1280,720','2560,1440','3072,1728','3840,2160','5120,2880','7680,4320','1280,960','1920,1440','2048,1536','1440,900','1920,1200','2560,1440','3840,2400','2560,1080','3440,1440','5120,2160']
        options.add_argument("window-size=(random.choice(Resolutions))")
        options.add_experimental_option('useAutomationExtension', False)
        options.add_argument('--disable-blink-features=AutomationControlled')
        options.add_experimental_option("excludeSwitches", ["enable-automation"])
        options.add_argument("--disable-gpu")
        options.add_experimental_option("prefs", 
        {"profile.default_content_setting_values.notifications": 1})
        prefs = {"enable_do_not_track": True}
#Useragent    
        from fake_useragent import UserAgent
        ua = UserAgent()
        a = ua.random
        user_agent = ua.random
        options.add_argument(f'user-agent={user_agent}')
#Chrome and Link
        URLS = open('Links.txt').read().splitlines()
        URLSR = random.choice(URLS)
        print(URLSR)
        driver = webdriver.Chrome(chrome_options=options)
        driver.minimize_window()
        driver.get(URLSR)
        sleep(7)
#Make Skipable
        try:
            button = driver.find_elements_by_xpath('//*[@id="home"]/a[1]')[0]
            button.click()
            sleep(0.25)
            driver.execute_script("window.open('');")
            driver.switch_to.window(driver.window_handles[0])
        except:
            print(f'{Fore.GREEN}Didnt Make Skipable')
#skip       
        button = driver.find_elements_by_xpath('//*[@id="skip_bu2tton"]')[0]
        button.click()
#Choose-tab
        driver.execute_script("window.open('');")
        driver.switch_to.window(driver.window_handles[0])
#Re-skip
        try:
            button = driver.find_elements_by_xpath('//*[@id="skip_bu2tton"]')[0]
            button.click()
        except:
                print(f'{Fore.GREEN}Didnt Re-skip')
        sleep(6)
#Go to Youtube
        try:
            button = driver.find_elements_by_xpath('//*[@id="no_display_msg"]/a')[0]
            button.click()
        except:
            print(f'{Fore.GREEN}Didnt Redirect by link')
        sleep(2)
#Consent
        try:
            button = driver.find_elements_by_xpath('/html/body/div[2]/div[3]/form/input[12]')[0]
            button.click()
            driver.minimize_window()
        except:
            print(f'{Fore.RED}Didnt Consent')
#If it worked then it will quit here
        sleep(0.25)
        driver.quit()
    except:
        print(f'{Fore.RED}Something went wrong')
#if it didnt then it will quit here
        driver.quit()
#Time till loop
sleep(0)